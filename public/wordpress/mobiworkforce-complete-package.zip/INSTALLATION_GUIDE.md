# WORKFORCE HEALTH SA — WordPress Installation & Deployment Guide

## 1. Package Contents
The WORKFORCE HEALTH SA WordPress suite is located in `/wordpress` and contains:

1. **`wfhsa-complete-suite.zip`** (Recommended): All-in-one consolidated plugin containing User Roles, 3-Step Location Selector, Inspections Engine, REST API sync endpoints, and PDF/Audit Report Generator.
2. **`wfhsa-theme.zip`**: The official dark industrial theme designed for WORKFORCE HEALTH SA and mining field operations.
3. **Modular Plugins** (For standalone activation if preferred):
   - `wfhsa-inspections.zip` (Core inspection checklist & scoring engine)
   - `wfhsa-location-selector.zip` (3-step Customer, Site & Ablution Facility wizard)
   - `wfhsa-user-roles.zip` (Field Assessor, Hygienist, Mine Manager, Admin roles)
   - `wfhsa-reports-pdf.zip` (Executive compliance certificate & PDF report generator)
4. **`wfhsa-complete-package.zip`**: Master distribution archive containing all plugins, theme, documentation, and database seeds.
5. **`sample-data.sql` / `wfhsa-sample-data.json`**: Pre-configured sample mining customer (`Letaba Crushers (Pty) Ltd`), sites, and assessments.

---

## 2. Fast Installation via WordPress Admin (Option A — Recommended)

### Step 1: Install the Theme
1. Navigate to your WordPress Admin dashboard (`https://wfhsa.com/wp-admin`).
2. Go to **Appearance > Themes > Add New > Upload Theme**.
3. Choose `wfhsa-theme.zip` from your `/wordpress` directory and click **Install Now**.
4. Click **Activate**.

### Step 2: Install the Plugin Suite
1. Go to **Plugins > Add New > Upload Plugin**.
2. Choose `wfhsa-complete-suite.zip` (or individual modular zip files if you prefer granular activation).
3. Click **Install Now**.
4. Click **Activate Plugin**.

### Step 3: Configure Pretty Permalinks
WordPress REST API routes require custom permalinks to be active:
1. Go to **Settings > Permalinks**.
2. Select **Post name** (`/%postname%/`).
3. Click **Save Changes**.

---

## 3. Fast Installation via WP-CLI (Option B — Server Command Line)

If you have SSH access to your web server at `https://wfhsa.com`:

```bash
# Navigate to WordPress root
cd /var/www/wfhsa.com/public_html

# Install and activate the theme
wp theme install /path/to/wfhsa-theme.zip --activate

# Install and activate the complete plugin suite
wp plugin install /path/to/wfhsa-complete-suite.zip --activate

# Update permalinks
wp rewrite structure '/%postname%/' --hard
wp rewrite flush --hard

# Verify active REST endpoints
wp rest-api-log list
```

---

## 4. REST API Endpoints Verification

The mobile Android application and offline background workers communicate with the following routes under namespace `wfhsa/v1`:

| HTTP Method | Route | Description |
|---|---|---|
| `GET` | `/wp-json/wfhsa/v1/health` | Server heartbeat, database status, and supported module version |
| `GET` | `/wp-json/wfhsa/v1/customers` | Hierarchical list of Authorized Customers, Sites & Facilities |
| `GET` | `/wp-json/wfhsa/v1/users/roles` | Role definitions (`Field Assessor`, `Hygienist`, `Mine Manager`, `Admin`) |
| `GET` | `/wp-json/wfhsa/v1/assessments` | List all assessments with status and compliance score % |
| `POST` | `/wp-json/wfhsa/v1/assessments` | Create or update inspection assessment payload |
| `GET` | `/wp-json/wfhsa/v1/assessments/{id}` | Detailed assessment record including responses and remedial items |
| `POST` | `/wp-json/wfhsa/v1/assessments/{id}/evidence` | Upload photographic violation evidence with GPS coordinates |
| `POST` | `/wp-json/wfhsa/v1/assessments/{id}/signature` | Store electronic dual sign-offs (Assessor & Mine Representative) |
| `POST` | `/wp-json/wfhsa/v1/sync` | Batch offline synchronization for Android Room database |
| `GET` | `/wp-json/wfhsa/v1/reports/{id}/html` | Printable Occupational Hygiene Audit & Certificate |
| `GET` | `/wp-json/wfhsa/v1/reports/{id}/pdf` | PDF download metadata and export URL |

### Health Check Test:
Run the following cURL test to verify connection:
```bash
curl -X GET https://wfhsa.com/wp-json/wfhsa/v1/health
```
Expected response:
```json
{
  "status": "ONLINE",
  "platform": "WORKFORCE HEALTH SA",
  "version": "1.1.0",
  "endpoint": "https://wfhsa.com/wp-json/wfhsa/v1",
  "server_time": "2026-10-30 10:15:00",
  "database": "PostgreSQL & WordPress Sync Layer"
}
```

---

## 5. Shortcodes Reference

Embed inspection and management controls into any WordPress page or post:

- `[wfhsa_location_selector]`: 3-Step selector wizard (Customer -> Site -> Facility).
- `[wfhsa_new_inspection]`: Full 51-question interactive inspection checklist wizard with live compliance score calculation.
- `[wfhsa_role_switcher]`: Interactive role switcher simulating Field Assessor, Hygienist, Mine Manager, and Admin permissions.
- `[wfhsa_dashboard]`: Executive inspection metrics, recent audits table, and sync health widget.
- `[wfhsa_report_viewer id="asm_letaba_01"]`: Embeds the formal Occupational Hygiene Compliance Certificate.

---

## 6. Seed Data Import
To populate your site with demo customers, sites, and initial inspection records:

### Via MySQL CLI:
```bash
mysql -u wordpress_user -p wordpress_db < /wordpress/sample-data.sql
```
