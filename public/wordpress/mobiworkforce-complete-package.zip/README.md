# WORKFORCE HEALTH SA — WordPress Enterprise Platform Package

This repository contains the complete production-grade WordPress backend and mobile API layer for the **WORKFORCE HEALTH SA Occupational Hygiene Digital Platform**, connecting field assessors at South African mining operations (e.g., Letaba Crushers, Tzaneen) directly to `https://wfhsa.com`.

---

## Architecture Highlights
- **Bi-Directional Mobile Sync:** Seamless integration with the Android Kotlin/Compose app via `/wp-json/wfhsa/v1/sync` supporting offline queuing, automatic retry, and Room database persistence.
- **51-Question Hygiene Module:** Authoritative digitisation of the Monthly Ablution Facilities Checklist (Male), categorized across Basins, Showers, Toilets, Urinals, Lockers, and General Sanitation/Chemicals.
- **Role-Based Workflow:** Distinct capabilities for:
  - `wfhsa_field_assessor`: Mobile data capture, voice-to-text notes, photo evidence with GPS stamps, draft saving.
  - `wfhsa_hygienist`: SAIOH registered oversight, corrective action review, audit approval.
  - `wfhsa_mine_manager`: Mine client counter-signing, compliance tracking, risk acknowledgment.
  - `wfhsa_system_admin`: Platform administration, customer/site registry, template management.
- **Local & Cloud PDF Reporting:** Generates print-ready formal Occupational Hygiene Compliance Certificates with score gauge, non-compliance matrix, and digital signature stamps.

---

## Directory Structure
```
wordpress/
├── INSTALLATION_GUIDE.md          # Step-by-step administrator setup manual
├── README.md                      # Architecture and package reference
├── sample-data.sql                # MySQL starter seed data
├── wfhsa-sample-data.json         # JSON structured demo records
├── wfhsa-complete-suite.zip       # All-in-one consolidated plugin archive
├── wfhsa-theme.zip                # Dark industrial responsive theme archive
├── wfhsa-complete-package.zip     # Master deployment package
├── plugins/
│   ├── wfhsa-complete-suite/      # Master all-in-one plugin source
│   ├── wfhsa-inspections/         # Core inspection engine and REST API
│   ├── wfhsa-location-selector/   # 3-Step Customer/Site/Facility wizard
│   ├── wfhsa-user-roles/          # Role and capability definitions
│   └── wfhsa-reports-pdf/         # Certificate & PDF report generator
└── themes/
    └── wfhsa-theme/               # WorkForce Health SA theme source
```

For installation steps, see [INSTALLATION_GUIDE.md](./INSTALLATION_GUIDE.md).
