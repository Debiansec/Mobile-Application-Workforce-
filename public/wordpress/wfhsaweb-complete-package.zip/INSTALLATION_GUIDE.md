# WFHSA WEB — WordPress Installation & Deployment Guide

## 1. Package Contents
The WFHSA Web WordPress suite is located in `/wordpress` and contains:

1. **`wfhsaweb-theme.zip`**: The official responsive dark industrial theme designed for WorkForce Health SA and South African mining field operations.
2. **`wfhsaweb-complete-suite.zip`** (Recommended): All-in-one consolidated plugin containing User Roles, 3-Step Location Selector, Inspections Engine (Voice + GPS), REST API sync endpoints, and PDF/Audit Report Generator.
3. **Modular Plugins** (For standalone activation if preferred):
   - `wfhsaweb-sync.zip` (Dedicated Android Sync REST API Engine for `https://wfhsa.com/new/wp-json/wfhsaweb/v1/sync`)
   - `wfhsaweb-user-roles.zip` (Field Assessor, Hygienist SAIOH, Mine Manager, Admin roles)
   - `wfhsaweb-location-selector.zip` (3-step Customer, Site & Ablution Facility wizard)
   - `wfhsaweb-inspections.zip` (Core inspection checklist & 51-point scoring engine with voice-to-text dictation & GPS geotagging)
   - `wfhsaweb-reports-pdf.zip` (Executive compliance certificate & PDF report generator)
4. **`wfhsaweb-complete-package.zip`**: Master distribution bundle containing theme, all plugins, documentation, and database seeds.
5. **`sample-data.sql` / `wfhsa-sample-data.json`**: Pre-configured sample mining customer (`Letaba Crushers (Pty) Ltd`), sites, and assessments.

---

## 2. Fast Installation via WordPress Admin (Option A — Recommended)

### Step 1: Install the Theme
1. Navigate to your WordPress Admin dashboard (`https://wfhsa.com/new/wp-admin`).
2. Go to **Appearance > Themes > Add New > Upload Theme**.
3. Choose `wfhsaweb-theme.zip` from your `/wordpress` directory and click **Install Now**.
4. Click **Activate**.

### Step 2: Install the Plugin Suite
1. Go to **Plugins > Add New > Upload Plugin**.
2. Choose `wfhsaweb-complete-suite.zip` (or individual modular zip files such as `wfhsaweb-inspections.zip` and `wfhsaweb-sync.zip`).
3. Click **Install Now**.
4. Click **Activate Plugin**.

### Step 3: Configure Pretty Permalinks
WordPress REST API routes require custom permalinks to be active:
1. Go to **Settings > Permalinks**.
2. Select **Post name** (`/%postname%/`).
3. Click **Save Changes**.

---

## 3. Fast Installation via WP-CLI (Option B — Server Command Line)

If you have SSH access to your web server at `https://wfhsa.com/new/`:

```bash
# Navigate to WordPress root
cd /var/www/wfhsa.com/new/public_html

# Install and activate the WFHSA Web theme
wp theme install /path/to/wfhsaweb-theme.zip --activate

# Install and activate the complete plugin suite
wp plugin install /path/to/wfhsaweb-complete-suite.zip --activate

# Flush rewrite rules for REST API endpoints
wp rewrite flush
```

---

## 4. Verification & Testing

Verify that the endpoints respond at `https://wfhsa.com/new/`:

- Health Check: `GET /wp-json/wfhsaweb/v1/health`
- Checklist Matrix: `GET /wp-json/wfhsaweb/v1/checklist/questions`
- Sync Ingestion: `POST /wp-json/wfhsaweb/v1/sync`
- Submit Inspection: `POST /wp-json/wfhsaweb/v1/inspections/submit`
